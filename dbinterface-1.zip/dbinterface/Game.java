/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbinterface;

import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Aleksandr Golovin
 */
public class Game {
    private String title;
    private String summary;
    private String releaseDate;
    private int ageSuggestion;
 
    private String siteName;
    private String url;
    private float price;
    
    private String review;
    private int rating;
    
    Game(){
            title="No title";
            summary= "No Summary Yet";
            releaseDate= "Game might not be out yet";
            ageSuggestion= -1;
            
            siteName= "No site";
            url= "No site"; 
            price= -1;
            
            review="No reviews yet";
            rating=-1;
    }
    
    // Set attributes from videogame table
    public void setGame(ResultSet rs){
        try{
            title=rs.getString("title");
            
            // Handles no summary
            if(rs.getString("summary") != null)
            {
                summary= rs.getString("Summary");
            }
            
            // Handles no release date
            if(rs.getString("releasedate") != null)
            {
                releaseDate= rs.getString("releasedate");
            }
            
            ageSuggestion= rs.getInt("ageSuggestion");
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }    
    }
    
    // Set attributes from outside site
    public void setSite(ResultSet rs){
        try{
            // Handles no sitename
            if(rs.getString("SiteName")!= null)
            {
                siteName= rs.getString("SiteName");
            }
            
            // Handles no url
            if(rs.getString("url")!=null)
            {
                url= rs.getString("url");
            }
            
            // Handles no price
            if(rs.getFloat("GamePrice") >0)
            {
                price= rs.getFloat("GamePrice");
            }
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
    }
    
    // Set attribute for review
    public void setReview(ResultSet rs){
        try{
            // Handles no comments
            if(rs.getString("comments")!=null)
            {
                review= rs.getString("comments"); 
            }
            
            // Handles no rating
            if(rs.getInt("rating")>0)
            {
                rating= rs.getInt("rating");
            }
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
    }
    
    public String getTitle(){
        return title;
    }
    
    public String getSummary(){
        return summary;
    }
    
    public String getReleaseDate(){
        return releaseDate;
    }
    
    public int getAge(){
        return ageSuggestion;
    }
    
    public String getUrl(){
        return url;
    }
    
    public String getSiteName(){
        return siteName;
    }
    
    public Float getPrice(){
        return price;
    }
    
    public String getComments(){
        return review;
    }
    
    public int getRating(){
        return rating;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbinterface;
import dbinterface.SearchWindow;

/**
 *
 * @author Aleksandr Golovin
 */
public class DBInterface {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Create a new window
        SearchWindow start= new SearchWindow();
        
        // Make window visible
        start.setVisible(true);
    }
}
